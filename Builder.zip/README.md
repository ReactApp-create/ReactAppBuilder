# REACT FIREBASE ADMIN

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).
For project instalation videos and docuemtnation go [here](http://fireadmin.mobidonia.com/).

# DEPLOYMENT INFO

| Project                 | Status | 
|-------------------------|--------|
| [React App Builder demo](https://make.reactappbuilder.com/)  |[![Netlify Status](https://api.netlify.com/api/v1/badges/26ca5271-b8fa-4ce3-bef0-2fc74df669e8/deploy-status)](https://app.netlify.com/sites/trusting-neumann-c10f0d/deploys)    |
